package com.example.formulriosimples;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.MultiAutoCompleteTextView;
import android.widget.Switch;
import android.widget.ToggleButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity2 extends AppCompatActivity {

    EditText tfNome, tfIdade, tfEmail, tfTelefone;
    ToggleButton genero;
    Switch situacao;
    Button btnEnviar;
    String tipoSituacao;
    String tipoGenero;
    MultiAutoCompleteTextView resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        tfNome = findViewById(R.id.tfNome);
        tfEmail = findViewById(R.id.tfEmail);
        tfTelefone = findViewById(R.id.tfTelefone);
        tfIdade = findViewById(R.id.tfIdade);
        genero = findViewById(R.id.genero);
        situacao = findViewById(R.id.situacao);
        btnEnviar = findViewById(R.id.btnEnviar);
        resultado = findViewById(R.id.resultado);

        situacao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (situacao.isChecked()) {
                    tipoSituacao = "Ativo";
                } else {
                    tipoSituacao = "Desativado";
                }
            }
        });

        genero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (genero.isChecked()){
                    tipoGenero = "Feminino";
                } else {
                    tipoGenero = "Masculino";
                }
            }
        });

        btnEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultado.setText("Nome: " + tfNome.getText() + "\n"
                        + "Idade: " + tfIdade.getText() + "\n"
                        + "Email: " + tfEmail.getText() + "\n"
                        + "Telefone: " + tfTelefone.getText() + "\n"
                        + "Gênero: " + tipoGenero + "\n"
                        + "Situação" + tipoSituacao);
            }
        });

    }
}