package com.example.imc;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText tfNome, tfIdade, tfAltura, tfPeso;

    Button btnCalc;

    TextView Resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

            btnCalc = findViewById(R.id.btnCalc);
            tfAltura = findViewById(R.id.tfAltura);
            tfIdade = findViewById(R.id.tfIdade);
            tfNome = findViewById(R.id.tfNome);
            tfPeso = findViewById(R.id.tfPeso);
            Resultado = findViewById(R.id.Resultado);


        btnCalc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String nome = tfNome.getText().toString();
                double Altura = Double.parseDouble(tfAltura.getText().toString());
                double Peso = Double.parseDouble(tfPeso.getText().toString());
                int Idade = Integer.parseInt(tfIdade.getText().toString());
                double total = Peso / (Altura * Altura);


                if (total < 18.5) {
                    Resultado.setText("Nome: " + nome + " | Idade: " + Idade + " | Classificação: Você está abaixo do peso");
                } else if (total < 25) {
                    Resultado.setText("Nome: " + nome + " | Idade: " + Idade + " | Classificação: Você está no peso normal");
                } else if (total < 30) {
                    Resultado.setText("Nome: " + nome + " | Idade: " + Idade + " | Classificação: Você está com sobrepeso");
                } else if (total < 35) {
                    Resultado.setText("Nome: " + nome + " | Idade: " + Idade + " | Classificação: Você está com obesidade grau 1");
                } else if (total < 40) {
                    Resultado.setText("Nome: " + nome + " | Idade: " + Idade + " | Classificação: Você está com obesidade grau 2");
                } else if (total < 50) {
                    Resultado.setText("Nome: " + nome + " | Idade: " + Idade + " | Classificação: Você está com obesidade grau 3");
                } else if (total < 60) {
                    Resultado.setText("Nome: " + nome + " | Idade: " + Idade + " | Classificação: Você está com obesidade grau 4");
                } else if (total > 60) {
                    Resultado.setText("Nome: " + nome + " | Idade: " + Idade + " | Classificação: Você está com obesidade grau 5");
                }

            }
        });

    }
}
