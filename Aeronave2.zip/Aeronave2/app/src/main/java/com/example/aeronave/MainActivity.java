package com.example.aeronave;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.MultiAutoCompleteTextView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    Button btnSubir, btnDescer, btnAut, btnAutDescer, btnCheck, btnLigar, btnDesligar;

    MultiAutoCompleteTextView TextArea;

    boolean AeronaveLigada = false;

    boolean CheckList = false;

    boolean AutorizacaoSubir = false;

    boolean AutorizacaoDescer = false;

    int Altura = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

                            btnAut = findViewById(R.id.btnAut);
                            btnSubir = findViewById(R.id.btnSubir);
                            btnDescer = findViewById(R.id.btnDescer);
                            btnAutDescer = findViewById(R.id.btnAutDescer);
                            btnCheck = findViewById(R.id.btnCheck);
                            btnLigar = findViewById(R.id.btnLigar);
                            btnDesligar = findViewById(R.id.btnDesligar);
                            TextArea = findViewById(R.id.TextArea);

    btnLigar.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            AeronaveLigada = true;
            TextArea.setText("Aeronave ligadaaaaaa");
        }
    });

    btnCheck.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            CheckList = true;
            TextArea.setText("Check List foiiiiiii");
        }
    });

    btnAut.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            AutorizacaoSubir = true;
            TextArea.setText("A aeronave está autorizada a subir");
        }
    });

    btnSubir.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (AeronaveLigada && CheckList && AutorizacaoSubir){
                Altura = Altura + 10000;
                TextArea.setText(String.valueOf(Altura));
            } else{
                TextArea.setText("É necessário que a Aeronave esteja Ligada, CheckList feito e tenha autorização para subir!!!");
            }
        }
    });

    btnAutDescer.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
                    if (Altura < 1000){
                        TextArea.setText("NÃO está autorizada para descer");
                    } else {
                        TextArea.setText("A nave está autorizada para descer");
                        AutorizacaoDescer = true;
                    }

        }
    });

    btnDescer.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (AutorizacaoDescer) {
                Altura = Altura -10000;
                TextArea.setText(String.valueOf(Altura));
            } else {
                TextArea.setText("Não está autorizada para descer!");
            }
        }
    });

    btnDesligar.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (Altura == 0 && AeronaveLigada) {
                AeronaveLigada = false;
                TextArea.setText("A aeronave está desligada");
            }
        }
    });

     }
    }
