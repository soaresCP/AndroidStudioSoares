package com.example.appcalculogua;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.MultiAutoCompleteTextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    Button btnEnviar;
    MultiAutoCompleteTextView Text;
    EditText tfNome, tfIdade, tfPeso, tfTemp;
    Double n1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnEnviar = findViewById(R.id.btnEnviar);
        Text = findViewById(R.id.Text);
        tfNome = findViewById(R.id.tfNome);
        tfIdade = findViewById(R.id.tfIdade);
        tfPeso = findViewById(R.id.tfPeso);
        tfTemp = findViewById(R.id.tfTemp);

        btnEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                double temp = Double.parseDouble(tfTemp.getText().toString());
                double peso = Double.parseDouble(tfPeso.getText().toString());

                if (tfNome.getText().toString().isEmpty() ||
                        tfTemp.getText().toString().isEmpty() ||
                        tfIdade.getText().toString().isEmpty() ||
                        tfPeso.getText().toString().isEmpty()) {

                    Text.setText("Todas as perguntas precisam ser respondidas para se obter o resultado!");
                } else if (temp <= 32) {
                    n1 = peso * 35;
                    Text.setText(tfNome.getText() + " você deve ingerir  a quantidade de água em ml: " + n1.toString());
                } else if (temp <= 37) {
                    n1 = peso * 45;
                    Text.setText(tfNome.getText() + " você deve ingerir  a quantidade de água em ml: " + n1.toString());
                } else if (temp > 37) {
                    n1 = peso * 65;
                    Text.setText(tfNome.getText() + " você deve ingerir  a quantidade de água em ml: " + n1.toString());
                }
            }
        });

    }
}