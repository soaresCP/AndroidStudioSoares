package com.example.raquetemosquito;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.MultiAutoCompleteTextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    Button btnLigar, btnCarga, btnUsar;
    MultiAutoCompleteTextView Text;

    int Carga = 0;
    boolean RaqueteLigada = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnCarga = findViewById(R.id.btnCarga);
        btnLigar = findViewById(R.id.btnLigar);
        btnUsar = findViewById(R.id.btnUsar);
        Text = findViewById(R.id.Text);


        btnCarga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Carga = 100;
                Text.append("A raquete foi carregada em 100%" + "\n");
            }
        });

        btnLigar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Carga > 0){
                    RaqueteLigada = true;
                    Text.append("A raquete está ligada" + "\n");
                } else {
                    Text.append("Não foi possível ligar a raquete");
                }
            }
        });

        btnUsar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (RaqueteLigada && Carga > 0){
                    Carga = Carga - 10;
                    Text.append("A raquete foi utilzada e atualmente está com " + Carga + "% de bateria" + "\n");
                }
            }
        });

    }
}